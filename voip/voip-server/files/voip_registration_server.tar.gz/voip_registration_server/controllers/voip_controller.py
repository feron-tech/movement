import connexion
import pymysql
import six
import uuid

from voip_registration_server.models.api_response import ApiResponse  # noqa: E501
from voip_registration_server.models.experiment import Experiment  # noqa: E501
from voip_registration_server import util

extension_template = (('Answer', ''),
                      ('Wait', '1'),
                      ('Monitor', 'wav,${EXTEN}'),
                      ('Playback', 'vm-msginstruct,skip'),
                      ('Hangup', ''))

def add_experiment(body):  # noqa: E501
    """Add a experiment

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: ApiResponse
    """
    if connexion.request.is_json:
        body = Experiment.from_dict(connexion.request.get_json())  # noqa: E501
    conn = pymysql.connect(host='127.0.0.1', user='root', passwd='monroe', db='asteriskrealtime')
    cur = conn.cursor()
    cur.execute("""INSERT IGNORE INTO `sip_buddies` SET `name` = '{}', 
                                                 `defaultuser` = '{}', 
                                                 `host` = 'dynamic', 
                                                 `type` = 'friend', 
                                                 `context` = 'from-sip', 
                                                 `secret` = '{}', 
                                                 `nat` = 'yes', 
                                                 `disallow` = 'all',
                                                 `allow` = 'ulaw;alaw',
                                                 `qualify` = 'no'""".format(body.node_id, body.node_id, body.node_id))
    if not body.experiment_id:
        body.experiment_id = str(uuid.uuid4()).upper()
    extension = "{}-{}".format(body.node_id, body.experiment_id)

    for i, exten_template in enumerate(extension_template):
        app, appdata = exten_template
        cur.execute("""INSERT IGNORE INTO `extensions` SET `context` = 'from-sip',
                                                    `exten` = '{}',
                                                    `priority` = '{}',
                                                    `app` = '{}',
                                                    `appdata` = '{}'""".format(extension, i+1, app, appdata))
    cur.close()
    conn.close()
    return extension


def delete_experiment(body):  # noqa: E501
    """Delete an experiment

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    conn = pymysql.connect(host='127.0.0.1', user='root', passwd='monroe', db='asteriskrealtime')
    cur = conn.cursor()
    cur.execute("DELETE FROM sip_buddies WHERE name = '{}'".format(body.node_id))
    cur.close()
    conn.close()
    if connexion.request.is_json:
        body = Experiment.from_dict(connexion.request.get_json())  # noqa: E501
    print(body)
    return 'do some magic delete!'


def find_experiments_by_node_id(status):  # noqa: E501
    """Finds experiments

    Multiple status values can be provided with comma separated strings # noqa: E501

    :param status: Status values that need to be considered for filter
    :type status: List[str]

    :rtype: List[Experiment]
    """
    return 'do some magic!'
