# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from voip_registration_server.models.api_response import ApiResponse  # noqa: E501
from voip_registration_server.models.experiment import Experiment  # noqa: E501
from voip_registration_server.test import BaseTestCase


class TestVoipController(BaseTestCase):
    """VoipController integration test stubs"""

    def test_add_experiment(self):
        """Test case for add_experiment

        Add a experiment
        """
        body = Experiment()
        response = self.client.open(
            '/voip-registration-api/1.0.0/experiments',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_experiment(self):
        """Test case for delete_experiment

        Delete an experiment
        """
        body = Experiment()
        response = self.client.open(
            '/voip-registration-api/1.0.0/experiments',
            method='DELETE',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_find_pets_by_status(self):
        """Test case for find_pets_by_status

        Finds experiments
        """
        query_string = [('status', 'available')]
        response = self.client.open(
            '/voip-registration-api/1.0.0/experiments/findByNodeId',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
